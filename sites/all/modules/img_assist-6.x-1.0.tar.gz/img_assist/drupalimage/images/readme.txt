The camera icon (camera.png) was taken from the 'slick' icon pack for KDE.  
As they are included in Debian, I'm assuming that they are compatible with the GPL.
