// German language variables

tinyMCE.addToLang('drupalimage', {
  title: 'Bild einfügen',
  desc: 'Ein vorhandenes Bild einfügen oder ein neues hochladen'
});
