// English language variables

tinyMCE.addToLang('drupalimage', {
  title: 'Drupal image',
  desc: 'Add an existing Drupal image or upload a new one.'
});
