$Id: README.txt,v 1.3 2008/04/06 16:43:19 sun Exp $

drupalimage plugin for TinyMCE
------------------------------

This plugin integrates the Drupal img_assist module with TinyMCE allowing
you to upload, browse and insert images into your post. Please read the
img_assist documentation for details.


Original plugin written by TinyMCE.module developers
Completely rewritten for Drupal 4.7 by BenShell (based on the TinyMCE Flash
plugin).

