// $Id: wysiwyg.init.js,v 1.2 2008/11/30 17:16:27 sun Exp $

Drupal.wysiwyg = Drupal.wysiwyg || { 'instances': {} };

Drupal.wysiwyg.editor = Drupal.wysiwyg.editor || { 'init': {}, 'attach': {}, 'detach': {} };

Drupal.wysiwyg.plugins = Drupal.wysiwyg.plugins || {};

