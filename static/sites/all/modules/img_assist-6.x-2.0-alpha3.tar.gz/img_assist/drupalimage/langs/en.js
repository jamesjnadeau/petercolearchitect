tinyMCE.addI18n('en.img_assist', {
  desc : 'Insert or update an embedded image.'
});
