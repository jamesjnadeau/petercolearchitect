tinyMCE.addI18n('de.img_assist', {
  desc: 'Bild einfügen oder aktualisieren.'
});
